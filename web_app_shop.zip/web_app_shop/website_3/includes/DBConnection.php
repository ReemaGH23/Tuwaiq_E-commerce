<?php
$servername = "localhost";
$username = "root";
$password = "";
$myDB = "website_Copy";

// Create connection
$conn = new mysqli($servername, $username, $password, $myDB);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}

session_start();

 ?>